#' @include utils.R
#' @include checks.R
#' @include R6_Model.R
#' @include R6_AgghooCV.R
#' @include agghoo.R
#' @include compareTo.R
NULL
